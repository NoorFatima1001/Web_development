// ========================= OFFERS MANAGEMENT =========================
document.addEventListener("DOMContentLoaded", () => {
  const offerForm = document.getElementById("offerForm");
  const offerList = document.getElementById("offerList");

  // Load offers from localStorage
  let offers = JSON.parse(localStorage.getItem("offers")) || [];

  // Display offers dynamically
  function displayOffers() {
    if (!offerList) return; // Safety check if offerList not present
    offerList.innerHTML = "";
    offers.forEach((offer, index) => {
      const card = document.createElement("div");
      card.className = "offer-card";
      card.innerHTML = `
        <strong>${offer.name}</strong>
        <p>${offer.description}</p>
        <div class="offer-buttons">
          <button class="edit-btn" onclick="editOffer(${index})">✏️ Edit</button>
          <button class="delete-btn" onclick="deleteOffer(${index})">🗑️ Delete</button>
        </div>
      `;
      offerList.appendChild(card);
    });
  }

  // Add or update offer
  if (offerForm) {
    offerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const id = document.getElementById("offerId").value;
      const name = document.getElementById("offerName").value.trim();
      const description = document.getElementById("offerDescription").value.trim();

      if (name === "" || description === "") {
        alert("Please fill in all fields.");
        return;
      }

      if (id === "") {
        offers.push({ name, description });
      } else {
        offers[id] = { name, description };
      }

      localStorage.setItem("offers", JSON.stringify(offers));
      offerForm.reset();
      document.getElementById("offerId").value = "";
      displayOffers();
    });
  }

  // Edit offer
  window.editOffer = function (index) {
    const offer = offers[index];
    document.getElementById("offerId").value = index;
    document.getElementById("offerName").value = offer.name;
    document.getElementById("offerDescription").value = offer.description;
  };

  // Delete offer
  window.deleteOffer = function (index) {
    if (confirm("Are you sure you want to delete this offer?")) {
      offers.splice(index, 1);
      localStorage.setItem("offers", JSON.stringify(offers));
      displayOffers();
    }
  };

  // Initial offer display
  displayOffers();

  // ========================= TESTIMONIALS SECTION =========================
  const showMoreBtn = document.getElementById("showMoreBtn");
  const hiddenReviews = document.querySelectorAll(".reviews-hide");
  let expanded = false;

  if (showMoreBtn) {
    showMoreBtn.addEventListener("click", () => {
      expanded = !expanded;

      hiddenReviews.forEach((review, index) => {
        if (expanded) {
          // Fade-in animation
          review.style.display = "flex";
          setTimeout(() => {
            review.classList.add("show");
            review.style.opacity = "1";
          }, index * 150);
        } else {
          review.classList.remove("show");
          setTimeout(() => {
            review.style.display = "none";
          }, 400);
        }
      });

      showMoreBtn.textContent = expanded
        ? "Show Fewer reviews "
        : "See More  ";
    });
  }

  // Optional auto-rotation for testimonials (bonus)
  const visibleReviews = document.querySelectorAll(".review");
  let index = 0;

  setInterval(() => {
    if (!expanded && visibleReviews.length > 1) {
      visibleReviews.forEach((review, i) => {
        review.style.display = i === index ? "flex" : "none";
      });
      index = (index + 1) % visibleReviews.length;
    }
  }, 6000);
});


  document.addEventListener("DOMContentLoaded", () => {
  const showMoreBtn = document.getElementById("showMoreBtn");
  const hiddenReviews = document.querySelectorAll(".reviews-hide");
  let expanded = false;

  showMoreBtn.addEventListener("click", () => {
    expanded = !expanded;

    hiddenReviews.forEach((review, index) => {
      if (expanded) {
        // Show with slight delay for a smooth "fade-in"
        setTimeout(() => {
          review.classList.add("show");
        }, index * 150);
      } else {
        review.classList.remove("show");
        setTimeout(() => {
          review.style.display = "none";
        }, 400);
      }
    });

    showMoreBtn.textContent = expanded
      ? "Show Fewer reviews "
      : "See More Reviews 😊";
  });
});

