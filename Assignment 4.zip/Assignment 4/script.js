document.addEventListener("DOMContentLoaded", () => {
  const offerForm = document.getElementById("offerForm");
  const offerList = document.getElementById("offerList");

  // Load offers from localStorage
  let offers = JSON.parse(localStorage.getItem("offers")) || [];

  // Display offers
  function displayOffers() {
    offerList.innerHTML = "";
    offers.forEach((offer, index) => {
      const card = document.createElement("div");
      card.className = "offer-card";
      card.innerHTML = `
        <strong>${offer.name}</strong>
        <p>${offer.description}</p>
        <button onclick="editOffer(${index})">Edit</button>
        <button onclick="deleteOffer(${index})">Delete</button>
      `;
      offerList.appendChild(card);
    });
  }

  // Add or update offer
  offerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("offerId").value;
    const name = document.getElementById("offerName").value;
    const description = document.getElementById("offerDescription").value;

    if (id === "") {
      offers.push({ name, description });
    } else {
      offers[id] = { name, description };
    }

    localStorage.setItem("offers", JSON.stringify(offers));
    offerForm.reset();
    document.getElementById("offerId").value = "";
    displayOffers();
  });

  // Edit offer
  window.editOffer = function(index) {
    const offer = offers[index];
    document.getElementById("offerId").value = index;
    document.getElementById("offerName").value = offer.name;
    document.getElementById("offerDescription").value = offer.description;
  };

  // Delete offer
  window.deleteOffer = function(index) {
    if (confirm("Are you sure you want to delete this offer?")) {
      offers.splice(index, 1);
      localStorage.setItem("offers", JSON.stringify(offers));
      displayOffers();
    }
  };

  // Initial display
  displayOffers();
});
