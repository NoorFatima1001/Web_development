// script.js

document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");
  const paymentMethod = document.getElementById("payment-method");
  const cardFields = document.getElementById("card-fields");
  const bankFields = document.getElementById("bank-fields");

  // ===============================
  // PAYMENT METHOD TOGGLE
  // ===============================
  if (paymentMethod) {
    paymentMethod.addEventListener("change", function () {
      cardFields?.classList.add("d-none");
      bankFields?.classList.add("d-none");

      if (this.value === "card") {
        cardFields?.classList.remove("d-none");
      } else if (this.value === "bank") {
        bankFields?.classList.remove("d-none");
      }
    });
  }

  // ===============================
  // FORM VALIDATION
  // ===============================
  if (form) {
    form.addEventListener("submit", function (event) {
      let valid = true;

      // Email
      const email = form.querySelector('input[type="email"]');
      const emailError = getErrorElement(email);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
        emailError.textContent = "Please enter a valid email address.";
        email.classList.add("is-invalid");
        valid = false;
      } else {
        emailError.textContent = "";
        email.classList.remove("is-invalid");
      }

      // Address
      const address = form.querySelectorAll('input[type="text"]')[1]; // 2nd text field = Address
      const addressError = getErrorElement(address);
      if (address.value.trim().length < 5) {
        addressError.textContent = "Address must be at least 5 characters.";
        address.classList.add("is-invalid");
        valid = false;
      } else {
        addressError.textContent = "";
        address.classList.remove("is-invalid");
      }

      // Phone
      const phone = form.querySelector('input[type="tel"]');
      const phoneError = getErrorElement(phone);
      if (!/^[0-9]{10,15}$/.test(phone.value.trim())) {
        phoneError.textContent = "Phone number must be 10–15 digits.";
        phone.classList.add("is-invalid");
        valid = false;
      } else {
        phoneError.textContent = "";
        phone.classList.remove("is-invalid");
      }

      if (!valid) {
        event.preventDefault();
      }
    });

    // Helper to show error messages
    function getErrorElement(input) {
      let error = input.nextElementSibling;
      if (!error || !error.classList.contains("invalid-feedback")) {
        error = document.createElement("div");
        error.className = "invalid-feedback";
        input.insertAdjacentElement("afterend", error);
      }
      return error;
    }
  }

  // ===============================
  // CRUD APP WITH JSONPLACEHOLDER
  // ===============================
  const apiURL = "https://jsonplaceholder.typicode.com/posts";
  const itemList = $("#item-list");
  const itemForm = $("#item-form");

  if (itemList.length && itemForm.length) {
    // READ (Get all items)
    function loadItems() {
      itemList.html("<tr><td colspan='4'>Loading...</td></tr>");
      $.get(apiURL, function (data) {
        itemList.empty();
        data.slice(0, 5).forEach((item) => {
          itemList.append(`
            <tr data-id="${item.id}">
              <td>${item.id}</td>
              <td class="title">${item.title}</td>
              <td class="body">${item.body}</td>
              <td>
                <button class="btn btn-sm btn-warning edit">Edit</button>
                <button class="btn btn-sm btn-danger delete">Delete</button>
              </td>
            </tr>
          `);
        });
      }).fail(() => {
        itemList.html("<tr><td colspan='4' class='text-danger'>Failed to load items.</td></tr>");
      });
    }
    loadItems();

    // CREATE (Add new item)
    itemForm.on("submit", function (e) {
      e.preventDefault();
      const newItem = {
        title: $("#title").val(),
        body: $("#body").val(),
        userId: 1,
      };

      $.post(apiURL, newItem, function (data) {
        itemList.append(`
          <tr data-id="${data.id}">
            <td>${data.id}</td>
            <td class="title">${data.title}</td>
            <td class="body">${data.body}</td>
            <td>
              <button class="btn btn-sm btn-warning edit">Edit</button>
              <button class="btn btn-sm btn-danger delete">Delete</button>
            </td>
          </tr>
        `);
        itemForm[0].reset();
      }).fail(() => {
        alert("Error: Could not add item.");
      });
    });

    // UPDATE (Edit item)
    itemList.on("click", ".edit", function () {
      const row = $(this).closest("tr");
      const id = row.data("id");
      const title = row.find(".title").text();
      const body = row.find(".body").text();

      $("#title").val(title);
      $("#body").val(body);

      itemForm.off("submit").on("submit", function (e) {
        e.preventDefault();
        const updatedItem = {
          title: $("#title").val(),
          body: $("#body").val(),
          userId: 1,
        };

        $.ajax({
          url: `${apiURL}/${id}`,
          method: "PUT",
          data: updatedItem,
          success: function () {
            row.find(".title").text(updatedItem.title);
            row.find(".body").text(updatedItem.body);
            itemForm[0].reset();
            itemForm.off("submit").on("submit", arguments.callee); // rebind
          },
          error: function () {
            alert("Error: Could not update item.");
          },
        });
      });
    });

    // DELETE (Remove item)
    itemList.on("click", ".delete", function () {
      const row = $(this).closest("tr");
      const id = row.data("id");

      if (confirm("Are you sure you want to delete this item?")) {
        $.ajax({
          url: `${apiURL}/${id}`,
          method: "DELETE",
          success: function () {
            row.remove();
          },
          error: function () {
            alert("Error: Could not delete item.");
          },
        });
      }
    });
  }
});
