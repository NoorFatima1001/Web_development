/* Pure JS Weather App
   Replace YOUR_API_KEY with your OpenWeatherMap API key.
   API docs: https://openweathermap.org/current
*/

const API_KEY = "971f95b774e851039682bce081256e16"; // <-- put your API key here

// Elements
const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const locBtn = document.getElementById("locBtn");
const statusEl = document.getElementById("status");
const weatherWrap = document.getElementById("weatherWrap");
const cityEl = document.getElementById("city");
const descEl = document.getElementById("desc");
const tempEl = document.getElementById("temp");
const feelsEl = document.getElementById("feels");
const iconEl = document.getElementById("icon");
const humidityEl = document.getElementById("humidity");
const windEl = document.getElementById("wind");
const pressureEl = document.getElementById("pressure");
const sunriseEl = document.getElementById("sunrise");
const updatedAtEl = document.getElementById("updatedAt");
const themeToggle = document.getElementById("themeToggle");

// helpers
const setStatus = (msg, isError = false) => {
  statusEl.textContent = msg || "";
  statusEl.style.color = isError ? "#ffbaba" : "";
};
const showLoading = (msg = "Loading...") => setStatus(msg);
const hideLoading = () => setStatus("");

function kToC(k) { return (k - 273.15).toFixed(1); }
function unixToLocalTime(unix, tzOffset = 0) {
  const date = new Date((unix + tzOffset) * 1000);
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
function formatDateTime(unix, tzOffset=0){
  const d = new Date((unix + tzOffset)*1000);
  return d.toLocaleString();
}

// Choose background image/color based on weather 'main'
function applyBackground(main) {
  const body = document.body;
  const m = (main || "").toLowerCase();
  if (m.includes("cloud")) {
    body.style.background = "linear-gradient(135deg,#e0eafc,#cfdef3)";
  } else if (m.includes("rain") || m.includes("drizzle") || m.includes("thunder")) {
    body.style.background = "linear-gradient(135deg,#89f7fe,#66a6ff)";
  } else if (m.includes("snow")) {
    body.style.background = "linear-gradient(135deg,#e6f0ff,#cfe9ff)";
  } else if (m.includes("clear") || m.includes("sun")) {
    body.style.background = "linear-gradient(135deg,#ffd89b,#19547b)";
  } else if (m.includes("mist") || m.includes("haze") || m.includes("fog")) {
    body.style.background = "linear-gradient(135deg,#d7d2cc,#304352)";
  } else {
    body.style.background = "linear-gradient(135deg,#74ABE2,#5563DE)";
  }
}

// Fetch current weather by city name
async function fetchWeatherByCity(city) {
  if (!city) return setStatus("Please enter a city.", true);
  showLoading("Fetching weather...");
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}`;
    const res = await fetch(url);
    if (!res.ok) {
      if (res.status === 404) throw new Error("City not found.");
      throw new Error("Failed to fetch weather.");
    }
    const data = await res.json();
    renderWeather(data);
    localStorage.setItem("lastCity", city);
  } catch (err) {
    setStatus(err.message, true);
    weatherWrap.classList.add("hidden");
  }
}

// Fetch current weather by coordinates (lat, lon)
async function fetchWeatherByCoords(lat, lon) {
  showLoading("Fetching weather...");
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Failed to fetch weather.");
    const data = await res.json();
    renderWeather(data);
    localStorage.setItem("lastCity", data.name);
  } catch (err) {
    setStatus(err.message, true);
    weatherWrap.classList.add("hidden");
  }
}

function renderWeather(data) {
  hideLoading();
  if (!data || !data.weather) {
    setStatus("Unexpected response from API.", true);
    return;
  }

  const w = data.weather[0];
  const main = data.main;
  const wind = data.wind;
  const sys = data.sys || {};
  const tz = data.timezone || 0;

  cityEl.textContent = `${data.name}, ${sys.country || ""}`;
  descEl.textContent = `${w.main} — ${w.description}`;
  tempEl.textContent = `${(main.temp - 273.15).toFixed(1)}°C`;
  feelsEl.textContent = `Feels like ${(main.feels_like - 273.15).toFixed(1)}°C`;
  humidityEl.textContent = `${main.humidity}%`;
  windEl.textContent = `${wind.speed} m/s`;
  pressureEl.textContent = `${main.pressure} hPa`;
  sunriseEl.textContent = sys.sunrise ? unixToLocalTime(sys.sunrise, tz) : "--:--";
  updatedAtEl.textContent = formatDateTime(Math.floor(Date.now() / 1000), 0);

  // icon from OpenWeatherMap
  const iconCode = w.icon;
  iconEl.src = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
  iconEl.alt = w.description || "weather icon";

  weatherWrap.classList.remove("hidden");
  setStatus("");

  // background
  applyBackground(w.main);
}

// Event handlers
searchBtn.addEventListener("click", () => {
  fetchWeatherByCity(cityInput.value.trim());
});
cityInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") fetchWeatherByCity(cityInput.value.trim());
});

locBtn.addEventListener("click", () => {
  if (!navigator.geolocation) {
    setStatus("Geolocation not supported by your browser.", true);
    return;
  }
  setStatus("Getting your location...");
  navigator.geolocation.getCurrentPosition((pos) => {
    const { latitude, longitude } = pos.coords;
    fetchWeatherByCoords(latitude, longitude);
  }, (err) => {
    setStatus("Unable to retrieve location: " + err.message, true);
  }, { timeout: 10000 });
});

// Theme toggle: remember in localStorage
function initTheme() {
  const saved = localStorage.getItem("theme") || "dark";
  if (saved === "light") document.body.classList.add("light-theme");
  themeToggle.textContent = saved === "light" ? "🌙" : "☀️";
}
themeToggle.addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light-theme");
  localStorage.setItem("theme", isLight ? "light" : "dark");
  themeToggle.textContent = isLight ? "🌙" : "☀️";
});

// On load: check last city
function init() {
  initTheme();
  const last = localStorage.getItem("lastCity");
  if (last) {
    cityInput.value = last;
    fetchWeatherByCity(last);
  } else {
    // show example / placeholder weather using a default city (optional)
    // fetchWeatherByCity("Lahore");
    setStatus("Search a city or use your location.");
  }
}

init();
